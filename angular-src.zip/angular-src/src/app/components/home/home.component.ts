import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  portfolio: String;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    if (this.authService.checkLoggedIn()) {
      this.authService.checkPortfolio().subscribe(data => {
        console.log(data);
        this.portfolio = data.success;
      })
    }
  }

}
