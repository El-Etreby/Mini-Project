import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: String;
  password: String;

  constructor(private router: Router, private flashMessagesService: FlashMessagesService, private authService: AuthService) { }

  ngOnInit() {
  }

  onLoginSubmit() {
    var student = {
      username: this.username,
      password: this.password
    }

    //Authenticate user
    this.authService.authenticateStudent(student).subscribe(data => {
      if (data.success) {
        this.authService.storeStudentData(data.token, data.student);
        this.flashMessagesService.show('You are now logged in', { cssClass: 'alert-success', timeout: 5000 });
        this.router.navigate(['']);

      } else {
        this.flashMessagesService.show(data.msg, { cssClass: 'alert-danger', timeout: 5000 });
        this.router.navigate(['login']);
      }
    })
  }

}
