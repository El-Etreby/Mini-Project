import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';
import { ModalComponent } from '../modal/modal.component'
import { Observable } from "rxjs/Observable"
import { FileUploader } from 'ng2-file-upload';
import 'rxjs/add/observable/interval';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  filesToUpload: Array<File>;
  filesToUploadProject: Array<File>;

  student: Object;
  portfolio: Object;

  projects: [Object];
  projectCount = 0;

  name: string;
  image: any;

  title: String;
  type: String = "url";
  details: String;
  screenshots = [];

  public readonly modal: ModalComponent;

  constructor(private authService: AuthService, private router: Router, private flashMessagesService: FlashMessagesService) {
    this.filesToUpload = [];
  }


  /*upload() {
    var portfolio = {
      name: this.name
    }
    this.authService.makeFileRequest("http://localhost:3000/student/upload", [], this.filesToUpload, portfolio).then((result) => {
      console.log(result);
    }, (error) => {
      console.error(error);
    });
  }*/

  fileChangeEvent(fileInput: any) {
    this.filesToUpload = <Array<File>>fileInput.target.files;
  }
  fileChangeEventProject(fileInput: any) {
    this.filesToUploadProject = <Array<File>>fileInput.target.files;
  }

  ngOnInit() {
    this.authService.getProfile().subscribe(profile => {
      this.student = profile.student;
      this.portfolio = profile.portfolio;
      this.authService.getProjects().subscribe(projects => {
        if (projects.success) {
          this.projectCount = projects.projects.length;
          this.projects = projects.projects;
        }
      })
    }, err => {
      this.flashMessagesService.show(err, { cssClass: 'alert-danger', timeout: 5000 });
      return false;
    })

  }

  getBase64($event) {
    var file = $event.target.files[0];
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (e) => {
      this.image = reader.result;
      console.log(this.image);
    };
    reader.onerror = function(error) {
      console.log('Error: ', error);
    };
  }
  getAllBase64Helper(file) {
    var reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (e) => {
      this.screenshots.push(reader.result);
      console.log(this.screenshots)
    };
    reader.onerror = function(error) {
      console.log('Error: ', error);
    };
  }
  getAllBase64($event) {
    var files = $event.target.files;
    if (files.length > 2) {
      this.flashMessagesService.show('The maximum number of screenshots to be uploaded is 2!', { cssClass: 'alert-danger', timeout: 3000 })
    } else {
      for (var i = 0; i < files.length; i++) {
        this.getAllBase64Helper(files[i]);
      }
    }
    /*for (var i = 0, file; file = files[i]; i++) {
      var reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        this.screenshots[i] = reader.result;
        console.log(this.screenshots)
      };
      reader.onerror = function(error) {
        console.log('Error: ', error);
      };
    } */
  }

  onSubmitPortfolio() {

    var portfolio = {
      name: this.name

    }
    this.authService.createPortfolio("http://localhost:3000/student/portfolio", [], this.filesToUpload, portfolio).then((data: any) => {
      if (data.success) {
        var project = {
          title: this.title,
          type: this.type,
          details: this.details
        }
        this.authService.addProject("http://localhost:3000/student/project", [], this.filesToUploadProject, project).then((data: any) => {
          if (data.success) {
            this.flashMessagesService.show('You have successfully created your portfolio', { cssClass: 'alert-success', timeout: 3000 });
            window.location.reload();
          } else {
            console.log('error')
          }
        })
      } else {
        console.log('error')
      }
    })

  }

  onSubmitProject() {
    var project = {
      title: this.title,
      type: this.type,
      details: this.details
    }
    this.authService.addProject("http://localhost:3000/student/project", [], this.filesToUploadProject, project).then((data: any) => {
      if (data.success) {
        this.flashMessagesService.show('You have added your project', { cssClass: 'alert-success', timeout: 3000 });
        window.location.reload();
      } else {
        console.log('error')
      }
    })
  }
}
