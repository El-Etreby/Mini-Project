import { Component, OnInit } from '@angular/core';
import { ValidateService } from '../../services/validate.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { AuthService } from '../../services/auth.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  email: String;
  username: String;
  password: String;
  studentId: Number;
  type: String;

  constructor(private validateService: ValidateService, private flashMessagesService: FlashMessagesService,
    private authService: AuthService, private router: Router) { }

  ngOnInit() {
    this.type = "client";

  }

  onRegisterSubmit() {
    if (this.type == "student") {
      var student = {
        email: this.email,
        username: this.username,
        password: this.password,
        //type: this.type,
        studentId: this.studentId

      }
      console.log(student)
    }

    //Validate Student
    if (!this.validateService.validateRegister(student)) {
      this.flashMessagesService.show('Please fill in the missing field(s)', { cssClass: 'alert-danger', timeout: 3000 });
      return false;
    }

    /*Email Validation
    if (!this.validateService.validateEmail(user.email)) {
      this.flashMessagesService.show('Please use a valid email', { cssClass: 'alert-danger', timeout: 3000 });
      return false;
    } */

    //Register Student
    this.authService.registerStudent(student).subscribe(data => {
      if (data.success) {
        this.flashMessagesService.show('You are now registered and can log in', { cssClass: 'alert-success', timeout: 3000 });
        this.router.navigate(['/login']);
      } else {
        this.flashMessagesService.show('Something went wrong', { cssClass: 'alert-danger', timeout: 3000 });
        this.router.navigate(['/register']);
      }
    });
  }
}
