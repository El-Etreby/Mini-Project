import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service'
import { FlashMessagesService } from 'angular2-flash-messages'

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  portfolios: [any];

  constructor(private authService: AuthService, private flashMessagesService: FlashMessagesService) { }

  ngOnInit() {
    this.authService.getPortfolios().subscribe(data => {
      if (data.portfolios.length != 0) {
        this.portfolios = data.portfolios;
      } else {
        this.flashMessagesService.show('No portfolios are available.', { cssClass: 'alert-danger', timeout: 3000 });
      }
    })
  }

}
