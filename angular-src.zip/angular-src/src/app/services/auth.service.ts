import { Injectable } from '@angular/core';
import { Http, Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import { tokenNotExpired } from 'angular2-jwt';

@Injectable()
export class AuthService {
  authToken: any;
  student: any;

  constructor(private http: Http) { }

  registerStudent(student) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/student/register', student, { headers: headers })
      .map(res => res.json());
  }

  authenticateStudent(student) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/student/authenticate', student, { headers: headers })
      .map(res => res.json());
  }

  storeStudentData(token, student) {
    localStorage.setItem('id_token', token);
    localStorage.setItem('user', JSON.stringify(student));
    this.authToken = token;
    this.student = student;
  }

  logoutStudent() {
    this.authToken = null;
    this.student = null;
    localStorage.clear();
  }

  getProfile() {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/student/profile', { headers: headers })
      .map(res => res.json());
  }


  loadToken() {
    var token = localStorage.getItem('id_token');
    this.authToken = token;
  }

  checkLoggedIn() {
    return tokenNotExpired();
  }

  checkPortfolio() {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/student/getPortfolio', { headers: headers })
      .map(res => res.json());
  }

  /*
    createPortfolio(data) {
      let headers = new Headers();
      this.loadToken();
      headers.append('Authorization', this.authToken);
      headers.append('Content-Type', 'application/json');
      return this.http.post('http://localhost:3000/student/portfolio', data, { headers: headers })
        .map(res => res.json());
    } */

  getProjects() {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/student/getProjects', { headers: headers })
      .map(res => res.json());
  }

  getPortfolios() {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/student/getPortfolios', { headers: headers })
      .map(res => res.json());
  }

  createPortfolio(url: string, params: Array<string>, files: Array<File>, portfolio) {
    this.loadToken();
    return new Promise((resolve, reject) => {
      var formData: any = new FormData();
      var xhr = new XMLHttpRequest();
      for (var i = 0; i < files.length; i++) {
        formData.append("uploads[]", files[i], files[i].name);
      }
      xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
          if (xhr.status == 200) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      }
      var portfolio1 = JSON.stringify(portfolio)
      xhr.open("POST", url, true);
      xhr.setRequestHeader("Authorization", this.authToken);
      formData.append("portfolio", portfolio1)
      xhr.send(formData);
    });
  }
  /*  addProject(project) {
      let headers = new Headers();
      this.loadToken();
      headers.append('Authorization', this.authToken);
      headers.append('Content-Type', 'application/json');
      return this.http.post('http://localhost:3000/student/project', project, { headers: headers })
        .map(res => res.json());
    }*/

  addProject(url: string, params: Array<string>, files: Array<File>, project) {
    this.loadToken();
    return new Promise((resolve, reject) => {
      var formData: any = new FormData();
      var xhr = new XMLHttpRequest();
      if (files) {
        for (var i = 0; i < files.length; i++) {
          formData.append("uploads[]", files[i], files[i].name);
        }
      }
      xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
          if (xhr.status == 200) {
            resolve(JSON.parse(xhr.response));
          } else {
            reject(xhr.response);
          }
        }
      }
      var project1 = JSON.stringify(project)
      xhr.open("POST", url, true);
      xhr.setRequestHeader("Authorization", this.authToken);
      formData.append("project", project1)
      xhr.send(formData);
    });
  }
}
